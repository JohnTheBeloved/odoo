{
    # Theme information
    'name' : 'Clarico Landing Page Layout1',
    'category' : 'Website',
    'version' : '1.0',
    'summary': 'Landing Page Style 1',
    'description': """""",

    # Dependencies
    'depends': [
        'clarico_cms_blocks'
    ],

    # Views
    'data': [
        'templates/template.xml',
    ],

    # Author
    'author': 'Emipro Technologies Pvt. Ltd.',
    'website': 'http://www.emiprotechnologies.com',

    # Technical
    'installable': True,
}
