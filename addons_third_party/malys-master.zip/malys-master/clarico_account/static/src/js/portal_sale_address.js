var my_account_address_el = document.querySelector('.div_class_my_account_address > address > div > div > i.fa-map-marker + span');
my_account_address_el.innerHTML = my_account_address_el.innerHTML.replace(/&nbsp;/g,'');



